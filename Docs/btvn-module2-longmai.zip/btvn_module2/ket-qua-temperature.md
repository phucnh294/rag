# BTVN Module 2 — Temperature Experiment

**Model:** llama3.1:8b (chạy qua Docker Compose, Ollama)
**Prompt:** "Viết hàm tính giai thừa bằng Python"

## Kết quả

| Temperature | Lần | eval_count (tokens) | Nội dung |
|---|---|---|---|
| 0.0 | 1 | 364 | Đúng đề — hàm giai thừa dùng vòng lặp for |
| 0.0 | 2 | 364 | **Giống hệt lần 1** (từng ký tự) |
| 0.0 | 3 | 364 | **Giống hệt lần 1 và 2** (từng ký tự) |
| 1.2 | 1 | 455 | Lạc đề — viết trò chơi "chiến tranh" bằng Python |
| 1.2 | 2 | 607 | Hiểu sai từ "giai thừa" → "giải thửa" (đất đai), lạc sang xử lý dữ liệu |
| 1.2 | 3 | 278 | Đúng đề — nhưng khác nội dung: đưa ra 3 cách giải (recursion, vòng lặp, math.prod) |

## Nhận định

Temperature = 1.2 giảm độ chính xác/bám sát đề của model, vì nhiệt độ cao làm
tăng tính ngẫu nhiên khi chọn token tiếp theo (không còn luôn chọn token xác
suất cao nhất), khiến 3 lần chạy cho 3 kết quả khác hẳn nhau — có lần lạc đề
hoàn toàn, có lần hiểu sai nghĩa từ đầu vào. Ngược lại, temperature = 0 luôn
chọn phương án xác suất cao nhất (greedy decoding), không có yếu tố ngẫu
nhiên, nên 3 lần chạy cho kết quả giống hệt nhau.

Cơ chế gây lạc đề ở nhiệt độ cao: một khi model chọn một token có xác suất
thấp hơn ở đầu câu trả lời (vd "giải thửa" thay vì "giai thừa"), token đó trở
thành context cho các token tiếp theo, khiến cả đoạn sau bị kéo lệch theo
hướng sai — hiện tượng dồn lỗi (error compounding), không phải do model
"hiểu sai" prompt gốc.

## Câu hỏi cho thầy

Temperature cao có thể khiến model hiểu sai nghĩa từ vựng đầu vào (không chỉ
đa dạng cách diễn đạt) — đây có phải hiện tượng phổ biến ở mọi kích thước
model, hay model nhỏ (8B) dễ bị ảnh hưởng hơn do phân phối xác suất ít sắc
nét hơn model lớn?
